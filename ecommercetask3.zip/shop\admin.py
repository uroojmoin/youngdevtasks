from django.contrib import admin
from .models import Product, Cart, CartItem, Order, ProductImage

# Register Product and ProductImage
admin.site.register(Product)
admin.site.register(ProductImage)

# Register CartItem
class CartItemAdmin(admin.ModelAdmin):
    list_display = ('cart', 'product', 'quantity', 'subtotal')
    search_fields = ('product__name',)

    def subtotal(self, obj):
        return obj.subtotal()
    subtotal.short_description = 'Subtotal'

admin.site.register(CartItem, CartItemAdmin)

# Register Cart
class CartAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at', 'total_price')
    search_fields = ('user__username',)

    def total_price(self, obj):
        return obj.total_price()
    total_price.short_description = 'Total Price'

admin.site.register(Cart, CartAdmin)

# Register Order
class OrderAdmin(admin.ModelAdmin):
    list_display = ('user', 'total_amount', 'status', 'created_at')
    search_fields = ('user__username', 'status')

admin.site.register(Order, OrderAdmin)
