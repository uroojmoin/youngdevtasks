from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Product, Cart, CartItem, Order

# Home Page
def home(request):
    return render(request, 'shop/home.html')

# Product List
def product_list(request):
    products = Product.objects.all()
    return render(request, 'shop/product_list.html', {'products': products})

# Add to Cart
@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_item, item_created = CartItem.objects.get_or_create(cart=cart, product=product)
    
    if not item_created:
        cart_item.quantity += 1
        cart_item.save()

    # Redirect to the cart view after adding the item
    return redirect('shop:cart_view')

# Fixing the indentation for some_view
def some_view(request):
    if condition:
        # Redirect to product list
        return redirect('shop:product_list')
    else:
        return render(request, 'some_template.html')

# Remove from Cart
@login_required
def remove_from_cart(request, item_id):
    item = get_object_or_404(CartItem, id=item_id)
    item.delete()
    return redirect('shop:cart_view')

# Cart View
@login_required
def cart_view(request):
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = CartItem.objects.filter(cart=cart)
    total_price = cart.total_price()  # Call the method as a function
    
    # Pass 'cart' as well
    return render(request, 'shop/cart.html', {
        'cart': cart,
        'cart_items': cart_items,
        'total_price': total_price
    })

# Checkout View
@login_required
def checkout(request):
    cart = Cart.objects.get(user=request.user)
    total_price = cart.total_price()  # Call the method as a function
    
    if request.method == "POST":
        # Create the order
        order = Order.objects.create(user=request.user, total_amount=total_price)
        
        # Clear the cart after order creation
        CartItem.objects.filter(cart=cart).delete()
        
        # Redirect to the order success page
        return redirect('shop:order_success')

    context = {
        'cart': cart,
        'cart_items': cart.cartitem_set.all(),  # Get all items in the cart
        'total_price': total_price
    }
    return render(request, 'shop/checkout.html', context)

# Order Success Page
def order_success(request):
    return render(request, 'shop/order_success.html')
